package com.mvccurd.deoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mvccurd.daoi.Daoi;
import com.mvccurd.utility.Jdbcutility;
import com.mvccurd.model.Student;


public class Daoimpl implements Daoi {

	@Override
	public int saveData(Student s) throws SQLException {

		String sql="insert into student(rollno,name,password,username,dob)values(?,?,?,?,?)";
		PreparedStatement ps=Jdbcutility.getConnection(sql);
	
			ps.setInt(1, s.getRollno());
			ps.setString(2, s.getName());
			ps.setString(3, s.getPassword());
			ps.setString(4, s.getUsername());
			ps.setString(5, s.getDob());
			int numberofrowupdate=ps.executeUpdate();
			
		return numberofrowupdate;
	}

	@Override
	public List<Student> getAlldata() throws SQLException {
		List<Student> list=new ArrayList<>();
		String sql="select * from student";
		PreparedStatement ps=Jdbcutility.getConnection(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next())

		{
			Student s=new Student();
			s.setRollno(rs.getInt(1));
			s.setName(rs.getString(2));
			
			s.setPassword(rs.getString(3));
			s.setUsername(rs.getString(4));
			s.setDob(rs.getString(5));
			
			list.add(s);
		}
		return list;
	}

	
	@Override
	public List<Student> deleteData(int rollno) throws SQLException {
		
		List<Student> list=new ArrayList<>();
		String sql="delete from student where rollno="+rollno;
		PreparedStatement ps=Jdbcutility.getConnection(sql);
		int rowdeleted=ps.executeUpdate();
		if(rowdeleted > 0)
		{
			list=getAlldata();
		}
		return list;
	}

	@Override
	public Student editData(int rollno) throws SQLException {
		System.out.println("edit data");
		Student s=new Student();
		String sql="select * from student where rollno="+rollno;
		
		PreparedStatement ps=Jdbcutility.getConnection(sql);
		ResultSet rs=ps.executeQuery();
		System.out.println("excute edit"+rs);
		while(rs.next())
		{		
			System.out.println("in while edit");
			s.setRollno(rs.getInt(1));
			s.setName(rs.getString(2));	
			s.setPassword(rs.getString(3));
			s.setUsername(rs.getString(4));
			s.setDob(rs.getString(5));
		}
		System.out.println("student data"+s.getRollno());
		return s;
	}

	@Override
	public List<Student> updateData(Student s) throws SQLException {

		System.out.println("update start");
		List<Student> list=new ArrayList<>();
		String sql="update student set name=?, password=?, username=?, dob=? where rollno=?";
		PreparedStatement ps=Jdbcutility.getConnection(sql);
		ps.setString(1, s.getName());
		ps.setString(2, s.getPassword());
		ps.setString(3, s.getUsername());
		ps.setString(4, s.getDob());
		ps.setInt(5, s.getRollno());
		int rowupdate=ps.executeUpdate();
		System.out.println();
		System.out.println("updated row "+rowupdate);
		
		if(rowupdate > 0)
		{	
			list=getAlldata();
		}
		else
		{
			System.out.println("errorrrr update");
		}
				return list;
	}
	
}
