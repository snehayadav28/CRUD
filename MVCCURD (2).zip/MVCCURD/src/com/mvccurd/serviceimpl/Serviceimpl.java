package com.mvccurd.serviceimpl;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mvccurd.daoi.Daoi;
import com.mvccurd.deoimpl.Daoimpl;
import com.mvccurd.servicei.Servicei;
import com.mvccurd.model.Student;

public class Serviceimpl implements Servicei {
		
	Daoi di=new Daoimpl();
	@Override
	public int saveData(Student s) throws SQLException {	
		return di.saveData(s);
	}
	@Override
	public List<Student> getAlldata() throws SQLException {
		return di.getAlldata();
	}
	
	@Override
	public List<Student> deleteData(int rollno) throws SQLException {
		return di.deleteData(rollno);
	}
	@Override
	public Student editData(int rollno)throws SQLException
	{
		return di.editData(rollno);
				
	}
	@Override
	public List<Student> updateData(Student s) throws SQLException {
		// TODO Auto-generated method stub
		return di.updateData(s);
	}

	
}
