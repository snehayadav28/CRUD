package com.mvccurd.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Jdbcutility {
	public static PreparedStatement getConnection(String sql)
	{
		PreparedStatement ps=null;
		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mvcstudent","root","root");
 		
		 ps=con.prepareStatement(sql);
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		return ps;
	}
	
}
