package com.mvccurd.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvccurd.servicei.Servicei;
import com.mvccurd.serviceimpl.Serviceimpl;
import com.mvccurd.model.Student;

@WebServlet(urlPatterns = "/reg")
public class RegistrationServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Student s = new Student();
		s.setRollno(Integer.parseInt(request.getParameter("rollno")));
		s.setName(request.getParameter("name"));
		s.setPassword(request.getParameter("password"));
		s.setUsername(request.getParameter("username"));
		s.setDob(request.getParameter("dob"));

		Servicei si = new Serviceimpl();
		try {
			si.saveData(s);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		rd.forward(request, response);

	}
}
