package com.mvccurd.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvccurd.servicei.Servicei;
import com.mvccurd.serviceimpl.Serviceimpl;
import com.mvccurd.model.Student;

@WebServlet(urlPatterns = "/myform")
public class EditServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("edit and delete servelet start");
		Student s = new Student();
		List<Student> list = new ArrayList<>();
		Servicei si = new Serviceimpl();
		int rollno = Integer.parseInt(request.getParameter("rollno"));

		System.out.println(rollno);
		request.setAttribute("data", s);

		String action = request.getParameter("action");

		if ("Edit".equals(action)) {
			System.out.println("edit");
			try {
			Student s1=	si.editData(rollno);
			request.setAttribute("data", s1);
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			rd.forward(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} 
		else if ("Delete".equals(action)) {
			try {
				System.out.println("delete");

				list = si.deleteData(rollno);
				request.setAttribute("data", list);

				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			System.out.println("error");
		}
	}

}
