package com.mvccurd.servicei;

import java.sql.SQLException;
import java.util.List;

import com.mvccurd.model.Student;

public interface Servicei {

	public int saveData(Student s)throws SQLException;
	public List<Student> getAlldata()throws SQLException ;
	public List<Student> deleteData(int rollno)throws SQLException;
	public Student editData(int rollno)throws SQLException;
	public List<Student> updateData(Student s)throws SQLException;
}
